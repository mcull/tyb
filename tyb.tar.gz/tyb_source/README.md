Thank You Back
=========

Demoware.  This app represents a hasty prototype, meaning every available shortcut and ugly hack was exercised in the interest of turnaround time.  Anyone reviewing this code with a mind to adapt or expand the functionality is advised to throw it all away without hesitation and start over from scratch.  
